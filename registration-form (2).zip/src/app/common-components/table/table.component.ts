
  import { Component, Input, OnInit } from '@angular/core';

  @Component({
      selector: 'app-table',
      templateUrl: './table.component.html',
      styleUrls: []
  })
  export class Table implements OnInit {
      @Input() data?: any;
      @Input() head?:any;
      data2 : any 
      clonedProducts: { [s: string]: any; } = {};
      constructor() {}

      ngOnInit() {
        this.data2 = this.data
      }
 
    onRowEditInit(head:any) {
        this.clonedProducts[head] = {...head};
       
    }
    deleteRow(id: any){
      console.log(id);
      for(let i = 0; i < this.data.length; ++i){
          if (this.data[i].id === id) {
              this.data.splice(i,1);
          }
      }
    }
    onRowEditSave(head: any) {
      
        if (Object.keys(head).length> 0) {
           delete this.clonedProducts[head];
           
        }  
       
    }
    onRowEditCancel(head: any, index: number) {
        this.data2[index] =  this.clonedProducts[head];
        delete this.data2[head[1]];
    }

    
  }
  