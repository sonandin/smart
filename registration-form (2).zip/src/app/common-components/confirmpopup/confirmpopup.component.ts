
import { Component, OnInit,  Input } from '@angular/core';
import {ConfirmationService, MessageService, PrimeNGConfig} from 'primeng/api';
    @Component({
        selector: 'app-confirmpopup',
        templateUrl: './confirmpopup.component.html',
        styleUrls: [], 
    })
    export class Confirmpopup implements OnInit {
       
        @Input() data?: any;
        constructor( private confirmationService: ConfirmationService,
        private messageService: MessageService,
        private primengConfig: PrimeNGConfig) {}

        confirm(event: Event) {
            this.confirmationService.confirm({
             // target: event.target,
              message:this.data.message,
              icon: "pi pi-exclamation-triangle",
              accept: () => {
                this.messageService.add({
                  severity: "info",
                  summary: "Confirmed",
                  detail: "You have accepted"
                });
              },
              reject: () => {
                this.messageService.add({
                  severity: "error",
                  summary: "Rejected",
                  detail: "You have rejected"
                });
              }
            });
          }
          
        ngOnInit() {}
        
    }
    