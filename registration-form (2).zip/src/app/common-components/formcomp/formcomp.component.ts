
    import { Component, OnInit, ViewEncapsulation } from '@angular/core';
    import { FormBuilder } from '@angular/forms';
    import { FormControl, Validators } from '@angular/forms';
    import { PrimeNGConfig, MenuItem } from 'primeng/api';
    import {Message,MessageService} from 'primeng/api';
    import { Accordion } from 'primeng/accordion';
    import {TreeNode} from 'primeng/api';
    import {FormService} from './formcomp.service'

    @Component({
        selector: 'app-formcomp',
        templateUrl: './formcomp.component.html',
        styleUrls: ['./formcomp.component.scss'],
        providers: [MessageService, Accordion],
        styles: [],
        encapsulation: ViewEncapsulation.None,
    })
    export class FormComp implements OnInit {
        activeIndex: number = 1;
        items: any[] = [];
        selectValues: any[] = [];
        selectedValue: any = null;
        selectedValueDropdown: any = null;
        date_bind: Date;
        uploadedFiles: any[] = [];
        rangeVal: any = null;
        colorpickerColor: string = '';
        inputmaskVal: string = '';

        showLoaderFlag: boolean = true;
        showLoader: boolean = true;
        // chartOptions: { plugins: { legend: { labels: { color: string; }; }; }; };
        chartOptions: any = {};

        fname: any;email: any;

        angularForm: any = this.formBuilder.group({
            fname: new FormControl('', [Validators.required, Validators.minLength(parseInt('')),Validators.maxLength(parseInt(''))]),
email: new FormControl('', [Validators.required]),

        
        });
        
        constructor(private formBuilder: FormBuilder,
            private primengConfig: PrimeNGConfig,
            private messageService: MessageService,
            private formService:FormService,
            ) { 
                this.items = [];
                this.date_bind = new Date();
                
            }

        ngOnInit() {
            this.primengConfig.ripple = true;
            
        }

        onSubmit() {
            if (this.angularForm.valid) {
                const _v = this.angularForm.value;
                const form = new FormData();
                console.log(_v);
                console.log(form);
                form.append('fname', _v.fname!);form.append('email', _v.email!);
            
            }
        }
        resetForm(){
            this.angularForm.reset();
          }

          onUpload(event: any) {
       
        }
        

        checked1: boolean = false;
        checked2: boolean = true;

        onclick(){}onclick(){}
    }