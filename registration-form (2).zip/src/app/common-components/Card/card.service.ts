

    import { HttpClient } from '@angular/common/http';
    import { Injectable } from '@angular/core';
    import {  Observable,  throwError } from 'rxjs';
    import { tap } from 'rxjs/operators';
    
    @Injectable({
      providedIn: 'root'
    })
    export class FormService {
      url = "https://jsonplaceholder.typicode.com/posts/1/comments";

      constructor(private http: HttpClient) { }
    
      methodForGET(apilink: any):Observable<any> {
        if ( apilink ) {
          this.url = apilink;
        }
        return this.http.get(this.url);
      }

      methodForPOST(apilink: any, payload: any):Observable<any>{
        if ( apilink ) {
          this.url = apilink;
        }
          return this.http.post(this.url,payload);
      }

      methodForPUT(apilink: any, data:any): Observable<any> {
        if ( apilink ) {
          this.url = apilink;
        }
          return this.http.put(this.url, data.payload);
      }
           
      methodForDELETE(apilink: any, id: any): Observable<any> {
        if ( apilink ) {
          this.url = apilink;
        }
        return this.http.delete<any>(this.url);  
      }
      
    }
  