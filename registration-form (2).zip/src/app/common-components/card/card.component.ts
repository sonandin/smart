
    import { Component, OnInit,  Input } from '@angular/core';
    import { PrimeNGConfig } from 'primeng/api';
    
    @Component({
        selector: 'app-card',
        templateUrl: './card.component.html',
        styleUrls: [],
    
    })
    export class Card implements OnInit {
       
        @Input() data?: any;
       
        constructor( private primengConfig: PrimeNGConfig ) {}
    
        ngOnInit() {
            this.primengConfig.ripple = true;
        }
        
    }
    