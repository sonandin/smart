
    import { Component, OnInit, ViewEncapsulation } from '@angular/core';
    import { FormBuilder } from '@angular/forms';
    import { FormControl, Validators } from '@angular/forms';
    import { PrimeNGConfig, MenuItem } from 'primeng/api';
    import {Message,MessageService} from 'primeng/api';
    import { Accordion } from 'primeng/accordion';
    import {TreeNode} from 'primeng/api';

    @Component({
        selector: 'app-comp',
        templateUrl: './comp.component.html',
        styleUrls: ['./comp.component.scss'],
        providers: [MessageService, Accordion],
        styles: [],
        encapsulation: ViewEncapsulation.None,
    })
    export class CompComponent implements OnInit {
        activeIndex: number = 1;
        items: any[] = [];
        selectValues: any[] = [];
        selectedValue: any = null;
        selectedValueDropdown: any = null;
        date_bind: Date;
        uploadedFiles: any[] = [];
        rangeVal: any = null;

        showLoaderFlag: boolean = true;
        showLoader: boolean = true;
        // chartOptions: { plugins: { legend: { labels: { color: string; }; }; }; };
        chartOptions: any = {};

        
            coldata1 = ["HEADER_TITLE_0","HEADER_TITLE_1","HEADER_TITLE_2","HEADER_TITLE_3"]
            rowdata1 = [{"HEADER_TITLE_3":"DATA_ROW_03","HEADER_TITLE_2":"DATA_ROW_02","flag":0,"HEADER_TITLE_1":"DATA_ROW_01","HEADER_TITLE_0":"DATA_ROW_00","value":null},{"HEADER_TITLE_3":"DATA_ROW_13","HEADER_TITLE_2":"DATA_ROW_12","flag":0,"HEADER_TITLE_1":"DATA_ROW_11","HEADER_TITLE_0":"DATA_ROW_10","value":null}]
    
        ConfirmPopupdata2 = JSON.parse(JSON.stringify({"border":"","paddingRight":"","letterSpacing":"","label":"ok","message":"Accepted","textColor":"","custom_class":"","marginLeft":"","marginRight":"","fontFamily":"","paddingBottom":"","borderRadius":"","dragndrop":true,"fontSize":"","marginBottom":"","disabled":false,"paddingTop":"","paddingLeft":"","fontWeight":"","marginTop":""}));
    

        
        
        constructor(private formBuilder: FormBuilder,
            private primengConfig: PrimeNGConfig,
            private messageService: MessageService,
            ) { 
                this.items = [];
                this.date_bind = new Date();
                
            }

        ngOnInit() {
            this.primengConfig.ripple = true;
            
        }

        

        checked1: boolean = false;
        checked2: boolean = true;

        
    }