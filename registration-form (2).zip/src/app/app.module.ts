import { CommonModule } from '@angular/common';import { HttpClientModule } from '@angular/common/http';import { BrowserAnimationsModule } from '@angular/platform-browser/animations';import { CommonComponentsModule } from './common-components/common-components.module'; import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccessDeniedModule } from './access-denied/access-denied.module';
import { LoginModule } from './login/login.module';
import { NotFoundModule } from './not-found/not-found.module';
import { ServerErrorModule } from './server-error/server-error.module';
import { SignupModule } from './signup/signup.module';
import { CompComponent } from './comp/comp.component';

@NgModule({
  declarations: [
    AppComponent,
    CompComponent
  ],
  imports: [ 
    CommonComponentsModule
    ,HttpClientModule,BrowserAnimationsModule, BrowserModule,
    AppRoutingModule,
    AccessDeniedModule,
    LoginModule,
    NotFoundModule,
    ServerErrorModule,
    SignupModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
